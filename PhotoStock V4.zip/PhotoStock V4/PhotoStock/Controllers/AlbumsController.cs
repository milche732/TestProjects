﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PhotoStock.Lib;
using PhotoStock.Lib.Models;

namespace PhotoStock.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlbumsController : ControllerBase
    {
        private readonly AlbumAggregator _albumManager;
        private readonly ILogger _logger;
        public AlbumsController(AlbumAggregator albumManager, ILogger<AlbumsController> logger)
        {
            _albumManager = albumManager;
            _logger = logger;
        }
        // GET: api/Albums
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                List<AlbumModel> albums = await _albumManager.GetAlbums();
                return Ok(albums);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "error during get all albums");
                return BadRequest("Error");
            }
        }

        // GET: api/Albums/5
        [HttpGet("{id}", Name = "Get")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                List<AlbumModel> albums = await _albumManager.GetAlbums(id);
                return Ok(albums);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"error during get by user {id}");
                return BadRequest("Error");
            }
        }
    }
}
