﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using PhotoStock.Lib.Infra;
using PhotoStock.Lib.Models;

namespace PhotoStock.Lib
{
    public class AlbumAggregator
    {
        private IDataProvider<Album> _albumProvider;
        private IDataProvider<Photo> _photoProvider;

        public AlbumAggregator(IDataProvider<Album> albumProvider, IDataProvider<Photo> photoProvider)
        {
            _albumProvider = albumProvider;
            _photoProvider = photoProvider;
        }
        public async Task<List<AlbumModel>> GetAlbums(int userId)
        {
            IEnumerable<Album> albums = (await _albumProvider.GetAsync()).Where(x => x.UserId == userId);
            List<Photo> photos = await _photoProvider.GetAsync();

            return Combine(albums, photos);
        }

        public async Task<List<AlbumModel>> GetAlbums()
        {
            List<Album> albums = await _albumProvider.GetAsync();
            List<Photo> photos = await _photoProvider.GetAsync();

            return Combine(albums, photos);
        }

        private List<AlbumModel> Combine(IEnumerable<Album> albums, IEnumerable<Photo> photos)
        {
            Dictionary<int, List<PhotoModel>> photoHash = new Dictionary<int, List<PhotoModel>>();

            foreach (Album x in albums)
            {
                if (!photoHash.ContainsKey(x.Id))
                    photoHash[x.Id] = new List<PhotoModel>();

            }

            foreach (Photo x in photos)
            { 
                if (photoHash.ContainsKey(x.AlbumId))
                    photoHash[x.AlbumId].Add(new PhotoModel {
                        PhotoId =x.Id,
                        Url = x.Url,
                        Title = x.Title,
                        ThumbnailUrl = x.ThumbnailUrl });
            };

            return albums.Select(x => new AlbumModel { AlbumId = x.Id, Title = x.Title, UserId = x.UserId, Photos = GetPhotosSafe(photoHash,x.Id) }).ToList();
        }

        private List<PhotoModel> GetPhotosSafe(Dictionary<int, List<PhotoModel>> photoHash, int album)
        {
            if (photoHash.ContainsKey(album))
                return photoHash[album];
            return null;
        }
    }
}
