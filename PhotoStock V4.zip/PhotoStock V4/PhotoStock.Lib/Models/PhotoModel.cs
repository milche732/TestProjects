﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PhotoStock.Lib.Models
{
    public class PhotoModel
    {
        public int PhotoId { get; set; }
        public string Url { get; set; }
        public string ThumbnailUrl { get; set; }
        public string Title { get; set; }
    }
}
