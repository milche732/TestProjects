﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PhotoStock.Lib.Models
{
    public class AlbumModel
    {
        public int UserId { get; set; }
        public int AlbumId { get; set; }
        public String Title { get; set; }

        public List<PhotoModel> Photos { get; set; }
    }
}
