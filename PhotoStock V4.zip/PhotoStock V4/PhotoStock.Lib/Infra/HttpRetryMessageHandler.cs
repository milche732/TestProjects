﻿using Polly;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PhotoStock.Lib.Infra
{
    public class HttpRetryMessageHandler : DelegatingHandler
    {
        private int _retry = 3;
        public HttpRetryMessageHandler( HttpClientHandler handler, int retry = 3) : base(handler) {
            _retry = retry;
        }

        protected override Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage request,
            CancellationToken cancellationToken) =>
            Policy
                .Handle<HttpRequestException>()
                .Or<TaskCanceledException>()
                .OrResult<HttpResponseMessage>(x => !x.IsSuccessStatusCode)
                .WaitAndRetryAsync(_retry, retryAttempt => TimeSpan.FromSeconds(Math.Pow(_retry, retryAttempt)))
                .ExecuteAsync(() => base.SendAsync(request, cancellationToken));
    }
}
