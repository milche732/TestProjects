﻿using Polly;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PhotoStock.Lib.Infra
{
    public class HttpJSONProvider: IJSONProvider
    {
        private string _url;
        private int _retry = 3;
        public HttpJSONProvider(string url, int retry = 3)
        {
            if (string.IsNullOrEmpty(url))
                throw new ArgumentNullException(nameof(url));
            _url = url;
            _retry = retry;
        }

        public async Task<string> GetContentAsync()
        {
            using (HttpClient client = new HttpClient(new HttpRetryMessageHandler(new HttpClientHandler(), _retry)))
            {
                using (HttpResponseMessage res = await client.GetAsync(_url))
                {
                    using (HttpContent content = res.Content)
                    {
                        return await content.ReadAsStringAsync();
                    }
                }
            }
        }
    }
}
