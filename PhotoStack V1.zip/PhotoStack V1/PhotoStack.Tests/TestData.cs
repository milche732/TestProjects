﻿using PhotoStock.Lib;
using System;
using System.Collections.Generic;
using System.Text;

namespace PhotoStack.Tests
{

    public class TestData
    {
        public static readonly List<Album> AlbumsList = new List<Album>
        {
            new Album{ UserId = 1,  Id =3, Title = "omnis laborum odio"},
            new Album{ UserId = 2,  Id =2, Title = "non esse culpa molestiae omnis sed optio"},
            new Album{ UserId = 1,  Id =25, Title = "eaque aut omnis a"}
        };

        public static readonly List<Photo> PhotoList = new List<Photo>
        {
            new Photo{ AlbumId =25, Id = 1231, Title = "enim quasi qui",
                Url = "https://via.placeholder.com/600/93d779",
                ThumbnailUrl = "https://via.placeholder.com/150/93d779"
            },
            new Photo{ AlbumId =25, Id = 1232, Title = "dolorum rerum fuga accusantium consequatur",
                Url = "https://via.placeholder.com/600/5e6cc",
                ThumbnailUrl = "https://via.placeholder.com/150/5e6cc"
            },
            new Photo{ AlbumId =4, Id = 1233, Title = "quo suscipit ullam sed ea",
                Url = "hhttps://via.placeholder.com/600/cd386a",
                ThumbnailUrl = "https://via.placeholder.com/150/cd386a"
            }
        };
        public const string ALBUMS = @"[
 {
    ""userId"": 1,
    ""id"": 3,
    ""title"": ""omnis laborum odio""
 },
  {
    ""userId"": 2,
    ""id"": 4,
    ""title"": ""non esse culpa molestiae omnis sed optio""
  },
  {
    ""userId"": 1,
    ""id"": 25,
    ""title"": ""eaque aut omnis a""
  }]";


        public const string PHOTOS = @"[
  {""albumId"": 25,
    ""id"": 1231,
    ""title"": ""enim quasi qui"",
    ""url"": ""https://via.placeholder.com/600/93d779"",
    ""thumbnailUrl"": ""https://via.placeholder.com/150/93d779""
  },
  {
    ""albumId"": 25,
    ""id"": 1232,
    ""title"": ""dolorum rerum fuga accusantium consequatur"",
    ""url"": ""https://via.placeholder.com/600/5e6cc"",
    ""thumbnailUrl"": ""https://via.placeholder.com/150/5e6cc""
  },
  {
    ""albumId"": 4,
    ""id"": 1233,
    ""title"": ""quo suscipit ullam sed ea"",
    ""url"": ""https://via.placeholder.com/600/cd386a"",
    ""thumbnailUrl"": ""https://via.placeholder.com/150/cd386a""
  }]";
    }


}
