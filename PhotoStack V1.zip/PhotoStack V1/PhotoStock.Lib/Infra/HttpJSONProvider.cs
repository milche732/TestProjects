﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PhotoStock.Lib.Infra
{
    public class HttpJSONProvider: IJSONProvider
    {
        private string _url;
        public HttpJSONProvider(string url)
        {
            if (string.IsNullOrEmpty(url))
                throw new ArgumentNullException(nameof(url));
            _url = url;
        }

        public async Task<string> GetContentAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                using (HttpResponseMessage res = await client.GetAsync(_url))
                {
                    using (HttpContent content = res.Content)
                    {
                        return await content.ReadAsStringAsync();
                    }
                }
            }
        }
    }
}
