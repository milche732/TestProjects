﻿using Newtonsoft.Json;
using PhotoStock.Lib.Infra;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PhotoStock.Lib.Infra
{
    public class DataProvider<T> : IDataProvider<T>
    {
        private IJSONProvider _fetcher;
        public DataProvider(IJSONProvider fetcher)
        {
            _fetcher = fetcher;
        }
        public virtual async Task<List<T>> GetAsync()
        {
            //Here we can also implement retry policy for better availibility
            string content = await _fetcher.GetContentAsync();

            return JsonConvert.DeserializeObject<List<T>>(content);
        }
        public virtual List<T> Get()
        {
            return GetAsync().Result;
        }
    }
}
