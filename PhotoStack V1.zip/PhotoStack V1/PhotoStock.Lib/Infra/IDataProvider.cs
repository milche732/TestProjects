﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PhotoStock.Lib.Infra
{
    public interface IDataProvider<T>
    {
        Task<List<T>> GetAsync();

        List<T> Get();
    }
}
