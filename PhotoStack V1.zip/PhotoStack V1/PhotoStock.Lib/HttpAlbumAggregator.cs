﻿using PhotoStock.Lib.Infra;
using System;
using System.Collections.Generic;
using System.Text;

namespace PhotoStock.Lib
{
    public class HttpAlbumAggregator : AlbumAggregator
    {
        public HttpAlbumAggregator(string albumUrl, string photoUrl) : base(
            new DataProvider<Album>(new HttpJSONProvider(albumUrl)),
            new DataProvider<Photo>(new HttpJSONProvider(photoUrl))
            )
        {

        }
    }
}
