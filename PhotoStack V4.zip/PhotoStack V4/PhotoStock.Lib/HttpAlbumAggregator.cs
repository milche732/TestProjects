﻿using PhotoStock.Lib.Infra;
using System;
using System.Collections.Generic;
using System.Text;

namespace PhotoStock.Lib
{
    public class HttpAlbumAggregator : AlbumAggregator
    {
        public HttpAlbumAggregator(string albumUrl, string photoUrl, int retry = 3) : base(
            new DataProvider<Album>(new HttpJSONProvider(albumUrl, retry)),
            new DataProvider<Photo>(new HttpJSONProvider(photoUrl, retry))
            )
        {

        }
    }
}
