using Moq;
using NUnit.Framework;
using PhotoStack.Tests;
using PhotoStock.Lib;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using PhotoStock.Lib.Infra;
using System;
using PhotoStock.Lib.Models;

namespace Tests
{
    public class PhotoAlbumUnitTests
    {
        [SetUp]
        public void Setup()
        {
          
        }
        [Test(Description = "Test on Empty URL for provider")]

        public void TestHttpJSONProviderNullArgument() {
            Assert.Throws<ArgumentNullException>(() => { new HttpJSONProvider(null); });
        }

        [Test (Description = "Check if provider IJSONProvider called")] 
        public void TestDataProviderCallsForJSON()
        {
            Mock<IJSONProvider> jsProvider = new Mock<IJSONProvider>();
            jsProvider.Setup(x => x.GetContentAsync()).Returns(Task.FromResult("[]"));

            DataProvider<Album> albumProvider = new DataProvider<Album>(jsProvider.Object);
            var result = albumProvider.GetAsync().Result;

            jsProvider.Verify(t => t.GetContentAsync());
        }

        [Test(Description = "Check if PhotoProvider correctly parses the data")]
        public void TestPhotoProviderDataStructure()
        {
            Mock<IJSONProvider> photoJSONProvider = new Mock<IJSONProvider>();
            photoJSONProvider.Setup(x => x.GetContentAsync()).Returns(Task.FromResult(TestData.PHOTOS));

            DataProvider<Photo> photoProvider = new DataProvider<Photo>(photoJSONProvider.Object);
            List<Photo> results = photoProvider.GetAsync().Result;

            Assert.IsNotNull(results);
            Assert.AreEqual(results.Count, 3);

            Assert.AreEqual(results[0].Id, 1231);
            Assert.AreEqual(results[0].Title, "enim quasi qui");
            Assert.AreEqual(results[0].Url, "https://via.placeholder.com/600/93d779");
            Assert.AreEqual(results[0].ThumbnailUrl, "https://via.placeholder.com/150/93d779");
        }

        [Test (Description = "Check if AlbumProvider correctly parses the data")] 
        public void TestAlbumProviderDataStructure()
        {
            Mock<IJSONProvider> albumJSONProvider = new Mock<IJSONProvider>();
            albumJSONProvider.Setup(x => x.GetContentAsync()).Returns(Task.FromResult(TestData.ALBUMS));

            DataProvider<Album> albumProvider = new DataProvider<Album>(albumJSONProvider.Object);
            List<Album> results = albumProvider.GetAsync().Result;

            Assert.IsNotNull(results);

            Assert.AreEqual(results.Count, 3);

            Assert.AreEqual(results[0].UserId, 1);
            Assert.AreEqual(results[0].Id, 3);
            Assert.AreEqual(results[0].Title, "omnis laborum odio");
        }

        [Test(Description = "Check if aggregator correctly combines data from two arrays")]
        public void TestAlbumAggregatorAllData()
        {
            Mock<IJSONProvider> jsProvider = new Mock<IJSONProvider>();
            Mock<DataProvider<Album>> albumProvider = new Mock<DataProvider<Album>>(jsProvider.Object);
            albumProvider.Setup(x => x.GetAsync()).Returns(Task.FromResult(TestData.AlbumsList));

            Mock<DataProvider<Photo>> photoProvider = new Mock<DataProvider<Photo>>(jsProvider.Object);
            photoProvider.Setup(x => x.GetAsync()).Returns(Task.FromResult(TestData.PhotoList));

            AlbumAggregator aggregator = new AlbumAggregator(
                albumProvider.Object,
                photoProvider.Object
            );

            List<AlbumModel> results = aggregator.GetAlbums().Result;
            Assert.IsNotNull(results);

            Assert.AreEqual(results.Count(), 3);

            Assert.AreEqual(results[2].UserId, TestData.AlbumsList[2].UserId);
            Assert.AreEqual(results[2].AlbumId, TestData.AlbumsList[2].Id);
            Assert.AreEqual(results[2].Title, TestData.AlbumsList[2].Title);
            Assert.AreEqual(results[2].Photos.Count, 2);
        }

        [Test( Description ="Check if aggregator correctly combines data from two arrays and filter by user id")]
        public void TestAlbumAggregatorByUserId()
        {
            Mock<IJSONProvider> jsProvider = new Mock<IJSONProvider>();
            Mock<DataProvider<Album>> albumProvider = new Mock<DataProvider<Album>>(jsProvider.Object);
            albumProvider.Setup(x => x.GetAsync()).Returns(Task.FromResult(TestData.AlbumsList));

            Mock<DataProvider<Photo>> photoProvider = new Mock<DataProvider<Photo>>(jsProvider.Object);
            photoProvider.Setup(x => x.GetAsync()).Returns(Task.FromResult(TestData.PhotoList));

            AlbumAggregator aggregator = new AlbumAggregator(
                albumProvider.Object,
                photoProvider.Object
            );

            int userId = 1;
            List<AlbumModel> results = aggregator.GetAlbums(userId).Result;
            Assert.IsNotNull(results);

            Assert.AreEqual(results.Count(), 2);

            Assert.AreEqual(results[1].UserId, userId);
            Assert.AreEqual(results[1].AlbumId, 25);
            Assert.AreEqual(results[1].Title, "eaque aut omnis a");
            Assert.AreEqual(results[1].Photos.Count, 2);
            Assert.AreEqual(results[1].Photos[0].PhotoId, 1231);
            Assert.AreEqual(results[1].Photos[0].Title, "enim quasi qui");
            Assert.AreEqual(results[1].Photos[0].ThumbnailUrl, "https://via.placeholder.com/150/93d779");
            Assert.AreEqual(results[1].Photos[0].Url, "https://via.placeholder.com/600/93d779");
        }
    }
}