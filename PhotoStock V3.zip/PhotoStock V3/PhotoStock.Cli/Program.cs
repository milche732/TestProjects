﻿using Newtonsoft.Json;
using PhotoStock.Lib;
using PhotoStock.Lib.Infra;
using System;
using System.Collections.Generic;

namespace PhotoStock.Cli
{
    class Program
    {
        static void Main(string[] args)
        {
            AlbumAggregator albumManager = new AlbumAggregator(
                new DataProvider<Album>(
                    new HttpJSONProvider("http://jsonplaceholder.typicode.com/albums")
                ),
                new DataProvider<Photo>(
                    new HttpJSONProvider("http://jsonplaceholder.typicode.com/photos")
               )
            );
            var result = albumManager.GetAlbums(1).Result;

            List<PhotoAlbum> albums = new List<PhotoAlbum>(result);
            Console.WriteLine("Albums: "+ albums.Count);
        }
    }
}
