﻿using System;

namespace PhotoStock.Lib
{
    public class Album
    {
        public int UserId { get; set; }
        public int Id { get; set; }
        public String Title { get; set; }
    }
}
