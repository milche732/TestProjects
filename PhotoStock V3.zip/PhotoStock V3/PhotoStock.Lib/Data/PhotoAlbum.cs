﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PhotoStock.Lib
{
    public class PhotoAlbum
    {
        public int UserId { get; set; }
        public int AlbumId { get; set; }
        public String Title { get; set; }

        public List<PhotoAlbumItem> Photos { get; set; }
    }
}
